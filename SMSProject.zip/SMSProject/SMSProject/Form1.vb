﻿Imports System.IO.Ports
Public Class Form1
    Dim GLOBAL_SMS_Message As String = ""
    Private Sub btnsend_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsend.Click

        SerialPort1 = New System.IO.Ports.SerialPort()
        SerialPort1.PortName = "COM11"
        SerialPort1.BaudRate = 9600
        SerialPort1.Parity = Parity.None
        SerialPort1.StopBits = StopBits.One
        SerialPort1.DataBits = 8
        SerialPort1.Handshake = Handshake.RequestToSend
        SerialPort1.DtrEnable = True
        SerialPort1.RtsEnable = True
        SerialPort1.NewLine = vbCrLf
        GLOBAL_SMS_Message = txtmsg.Text
        SerialPort1.Open()

        If SerialPort1.IsOpen() = True Then
            SerialPort1.Write("AT" & vbCrLf)
            SerialPort1.Write("AT+CMGF=1" & vbCrLf)
            SerialPort1.Write("AT+CMGS=" & Chr(34) & (TextBox1.Text) & Chr(34) & vbCrLf)
            SerialPort1.Write(GLOBAL_SMS_Message & Chr(26))
            MsgBox("Sent")
            SerialPort1.Close()

        Else
            MsgBox("Port not available")
        End If


    End Sub

End Class
