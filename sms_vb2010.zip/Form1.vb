﻿' Written By: Mr. Jake R. Pomperada, MAED-IT
' November 26, 2014
' Visual Basic 2010
' jakerpomperada@gmail.com and jakerpomperada@yahoo.com

Imports System.IO.Ports
Imports System.IO
Public Class Form1
    
    Dim SerialPort As New System.IO.Ports.SerialPort()
    Dim message As String

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        If SerialPort.IsOpen Then
            SerialPort.Close()
        End If
        SerialPort.PortName = "COM5"
        SerialPort.BaudRate = 9600
        SerialPort.Parity = Parity.None
        SerialPort.StopBits = StopBits.One
        SerialPort.DataBits = 8
        SerialPort.Handshake = Handshake.RequestToSend
        SerialPort.DtrEnable = True
        SerialPort.RtsEnable = True
        SerialPort.NewLine = vbCrLf

        message = RichTextBox1.Text
        SerialPort.Open()
        If SerialPort.IsOpen() Then
            SerialPort.Write("AT" & vbCrLf)
            SerialPort.Write("AT+CMGF=1" & vbCrLf)
            SerialPort.Write("AT+CMGS=" & Chr(34) & TextBox1.Text & Chr(34) & vbCrLf)
            SerialPort.Write(message & Chr(26))
            MsgBox("Text Message Successfully Send !!!")
        Else
            MsgBox("Port not available")
        End If
    End Sub
End Class



    