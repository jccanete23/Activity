-- phpMyAdmin SQL Dump
-- version 3.4.10.1deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 12, 2013 at 10:48 AM
-- Server version: 5.5.32
-- PHP Version: 5.3.10-1ubuntu3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `library`
--

-- --------------------------------------------------------

--
-- Table structure for table `brwbooks`
--

CREATE TABLE IF NOT EXISTS `brwbooks` (
  `brw_id` varchar(20) NOT NULL,
  `brw_name` varchar(50) NOT NULL,
  `bookid` varchar(20) NOT NULL,
  `booktle` varchar(50) NOT NULL,
  `dateissue` date NOT NULL,
  `datereturn` date NOT NULL,
  `no_copies` int(20) NOT NULL,
  UNIQUE KEY `brw_id` (`brw_id`,`bookid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brwbooks`
--

INSERT INTO `brwbooks` (`brw_id`, `brw_name`, `bookid`, `booktle`, `dateissue`, `datereturn`, `no_copies`) VALUES
('0107-01', 'Joe Basanta', '00001', 'Jquery Programming', '2013-09-27', '2013-09-28', 1),
('4654', 'Mar Nobleza', '00002', 'Jump Starts', '2013-09-27', '2013-09-28', 1),
('5525', 'Limuel Toinks', '00001', 'Jquery Programming', '2013-09-27', '2013-09-28', 41),
('5654', 'Aniano Anyare', '00001', 'Jquery Programming', '2013-09-27', '2013-09-28', 1),
('xfdxfdx', 'ghvghcvgv', '00001', 'Jquery Programming', '2013-09-03', '2013-09-03', 45);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `category` (`category`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `category`) VALUES
(11, 'Bulad'),
(9, 'Computer'),
(4, 'Health'),
(6, 'History'),
(3, 'Math'),
(10, 'Networking'),
(12, 'Pagkaon'),
(2, 'Programming'),
(5, 'Science'),
(8, 'Sports');

-- --------------------------------------------------------

--
-- Table structure for table `penalty`
--

CREATE TABLE IF NOT EXISTS `penalty` (
  `penalty` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `penalty`
--

INSERT INTO `penalty` (`penalty`) VALUES
(10);

-- --------------------------------------------------------

--
-- Table structure for table `reserve`
--

CREATE TABLE IF NOT EXISTS `reserve` (
  `reserve_id` varchar(20) NOT NULL,
  `reserve_name` varchar(50) NOT NULL,
  `bookid` varchar(20) NOT NULL,
  `booktle` varchar(50) NOT NULL,
  `dateissue` date NOT NULL,
  `pickup` date NOT NULL,
  `no_copies` int(20) NOT NULL,
  UNIQUE KEY `brw_id` (`reserve_id`,`bookid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reserve`
--

INSERT INTO `reserve` (`reserve_id`, `reserve_name`, `bookid`, `booktle`, `dateissue`, `pickup`, `no_copies`) VALUES
('45686', 'Ben Lausa', '00001', 'Jquery Programming', '2013-09-27', '2013-09-28', 1),
('6695', 'Samson Lausa', '00001', 'Jquery Programming', '2013-09-27', '2013-09-28', 1),
('67558', 'Robert Quingking', '00003', 'Panting way sakang', '2013-09-27', '2013-09-28', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblbooks`
--

CREATE TABLE IF NOT EXISTS `tblbooks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `book_id` varchar(20) NOT NULL,
  `bk_name` varchar(50) NOT NULL,
  `bk_ctry` varchar(50) NOT NULL,
  `bk_qty` int(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `book_id` (`book_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=28 ;

--
-- Dumping data for table `tblbooks`
--

INSERT INTO `tblbooks` (`id`, `book_id`, `bk_name`, `bk_ctry`, `bk_qty`) VALUES
(8, '00002', 'Jump Starts', 'Health', 18),
(9, '00003', 'Panting way sakang', 'Health', 9),
(10, '00001', 'Jquery Programming', 'Programming', 39),
(11, '00004', 'Hardware Servicing', 'Computer', 10),
(12, '00005', 'Bulad nga sapsap', 'Health', 20),
(13, '00006', 'Sapatos nga buslot', 'Sports', 5),
(14, '00007', 'Standard Cabling', 'Computer', 6),
(15, '00008', 'Program Development', 'Programming', 8),
(16, '00009', 'Computer Basic', 'Computer', 6),
(18, '00011', 'Jose Rizal', 'History', 23),
(19, '00012', 'Andress Bonifacio', 'History', 5),
(21, '00013', 'HTML Basic', 'Programming', 6),
(22, '00014', 'Boxing', 'Health', 5),
(23, '00015', 'Swimming', 'Health', 20),
(24, '00016', 'History of America', 'History', 5),
(25, '00017', 'UTP Cable', 'Computer', 5),
(27, '00018', 'Programming 2', 'Programming', 20);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(2, 'elmer', 'f533befa4916520baa425cbca4dcebd3'),
(23, 'admin', '5f4dcc3b5aa765d61d8327deb882cf99'),
(24, 'blocker25', '5f4dcc3b5aa765d61d8327deb882cf99'),
(25, 'Julian', '5f4dcc3b5aa765d61d8327deb882cf99');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
