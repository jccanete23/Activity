﻿Imports MySql.Data.MySqlClient
Public Class frmMoveborrow
    Dim mycnt As MySqlConnection
    Dim mysql As MySqlCommand

    Private Sub MTB_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MTB.Click
        mycnt = New MySqlConnection
        mycnt.ConnectionString = "server=localhost;userid=root;database=library;Convert Zero Datetime=True"
        Dim dr As MySqlDataReader
        Dim sqlAdapter As New MySqlDataAdapter
        Dim sqlCommand As New MySqlCommand
        Dim lv As New DataTable

        Try
            mycnt.Open()
            Dim qry = "insert into brwbooks(brw_id,contact_no,brw_name,bookid,booktle,author_name,no_copies)values('" & TxtRiD.Text & "','" & TxtContact.Text & "','" & TxtReserveName.Text & "','" & TxtBookid.Text & "','" & TxtBookTle.Text & "','" & TxtAuthorname.Text & "','" & TxtCopies.Text & "')"
            cmd = New MySqlCommand(qry, mycnt)
            da = cmd.ExecuteScalar
            mycnt.Close()

            mycnt.Open()
            Dim Query As String
            Query = "Delete from reserve where reserve_id='" & TxtRiD.Text & "'and bookid='" & TxtBookid.Text & "'"
            mysql = New MySqlCommand(Query, mycnt)
            dr = mysql.ExecuteReader
            MessageBox.Show("Successfully Return Book!")
            frmListreserve.listreserve()
            TxtRiD.Text = ""
            TxtContact.Text = ""
            TxtReserveName.Text = ""
            TxtBookid.Text = ""
            TxtBookTle.Text = ""
            TxtAuthorname.Text = ""
            TxtCopies.Text = ""
            mycnt.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            mycnt.Dispose()
        End Try
    End Sub

    Private Sub frmMoveborrow_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        mycnt = New MySqlConnection
        mycnt.ConnectionString =
            "server=localhost;userid=root;database=library;Convert Zero Datetime=True"
        Try
            mycnt.Open()
        Catch ex As Exception
            MessageBox.Show("Cannot Connect" + ex.Message)
        Finally
            mycnt.Dispose()
        End Try
    End Sub

    Private Sub Bck_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Bck.Click
        frmListreserve.Show()
        Me.Hide()
    End Sub

    Private Sub TxtContact_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TxtContact.KeyDown
        If e.KeyCode.Equals(Keys.Back) Then
            TxtContact.Clear()
        End If
    End Sub

    Private Sub TxtReserveName_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TxtReserveName.KeyDown
        If e.KeyCode.Equals(Keys.Back) Then
            TxtReserveName.Clear()
        End If
    End Sub

    Private Sub TxtReserveName_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TxtReserveName.KeyPress
        Dim allowedchars As String = "abcdefghijklnopqrstuvwxyz"
        If allowedchars.IndexOf(e.KeyChar) = -1 Then
            e.Handled = True
        End If
    End Sub

    Private Sub TxtCopies_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TxtCopies.KeyDown
        If e.KeyCode.Equals(Keys.Back) Then
            TxtCopies.Clear()
        End If
    End Sub

    Private Sub TxtCopies_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TxtCopies.KeyPress
        Dim allowedchars As String = "1234567890"
        If allowedchars.IndexOf(e.KeyChar) = -1 Then
            e.Handled = True
        End If
    End Sub
End Class