﻿Imports MySql.Data.MySqlClient

Public Class frmListborrow
    Dim mycnt As MySqlConnection
    Dim mysql As MySqlCommand
    Dim aqry As String

    Private Sub frmListborrow_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        mycnt = New MySqlConnection
        mycnt.ConnectionString = "server=localhost;userid=root;database=library;Convert Zero Datetime=True"
        Try
            mycnt.Open()
            listborrow()
        Catch ex As Exception
            MessageBox.Show("Cannot Connect" + ex.Message)
        Finally
            mycnt.Dispose()
        End Try
    End Sub

    Sub listborrow()
        ListView.Items.Clear()
        Dim sqlQuery As String = "select * from brwbooks; "

        Dim sqlAdapter As New MySqlDataAdapter
        Dim sqlCommand As New MySqlCommand
        Dim lv As New DataTable
        Dim i As Integer

        With sqlCommand
            .CommandText = sqlQuery
            .Connection = mycnt
        End With
        With sqlAdapter
            .SelectCommand = sqlCommand
            .Fill(lv)
        End With
        For i = 0 To lv.Rows.Count - 1
            With ListView
                .Items.Add(lv.Rows(i)("brw_id"))
                With .Items(.Items.Count - 1).SubItems
                    .Add(lv.Rows(i)("contact_no"))
                    .Add(lv.Rows(i)("brw_name"))
                    .Add(lv.Rows(i)("bookid"))
                    .Add(lv.Rows(i)("booktle"))
                    .Add(lv.Rows(i)("author_name"))
                    .Add(lv.Rows(i)("no_copies"))
                End With
            End With
        Next
    End Sub

    Sub search()
        ListView.Items.Clear()
        Dim sqlAdapter As New MySqlDataAdapter
        Dim sqlCommand As New MySqlCommand
        Dim lv As New DataTable
        Dim i As Integer

        With sqlCommand
            .CommandText = aqry
            .Connection = mycnt
        End With
        With sqlAdapter
            .SelectCommand = sqlCommand
            .Fill(lv)
        End With
        For i = 0 To lv.Rows.Count - 1
            With ListView
                .Items.Add(lv.Rows(i)("brw_id"))
                With .Items(.Items.Count - 1).SubItems
                    .Add(lv.Rows(i)("contact_no"))
                    .Add(lv.Rows(i)("brw_name"))
                    .Add(lv.Rows(i)("bookid"))
                    .Add(lv.Rows(i)("booktle"))
                    .Add(lv.Rows(i)("author_name"))
                    .Add(lv.Rows(i)("no_copies"))
                End With
            End With
        Next
    End Sub

    Private Sub BtnData_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnData.Click
        frmSending.Show()
    End Sub

    Private Sub Lsv3_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListView.SelectedIndexChanged
        frmSending.Txtnumber.Text = ListView.Items(ListView.FocusedItem.Index).SubItems(1).Text
        frmReturing.TxtRiD.Text = ListView.Items(ListView.FocusedItem.Index).SubItems(0).Text
        frmReturing.TxtContact.Text = ListView.Items(ListView.FocusedItem.Index).SubItems(1).Text
        frmReturing.TxtReserveName.Text = ListView.Items(ListView.FocusedItem.Index).SubItems(2).Text
        frmReturing.TxtBookid.Text = ListView.Items(ListView.FocusedItem.Index).SubItems(3).Text
        frmReturing.TxtBookTle.Text = ListView.Items(ListView.FocusedItem.Index).SubItems(4).Text
        frmReturing.TxtAuthorname.Text = ListView.Items(ListView.FocusedItem.Index).SubItems(5).Text
        frmReturing.TxtCopies.Text = ListView.Items(ListView.FocusedItem.Index).SubItems(6).Text
    End Sub

    Private Sub BtnBck_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnBck.Click
        frmMainAdmin.Show()
        Me.Hide()
    End Sub

    Private Sub BtnReturn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnReturn.Click
        frmReturing.Show()
    End Sub

    Private Sub btnSearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSearch.Click
        aqry = "select brw_id, contact_no, brw_name, bookid, booktle, author_name, no_copies from brwbooks where brw_name like '%" & Txtsearch.Text & "%' or brw_id like '%" & Txtsearch.Text & "%'"
        search()
    End Sub
End Class