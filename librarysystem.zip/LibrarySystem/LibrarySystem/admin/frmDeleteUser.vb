﻿Imports MySql.Data.MySqlClient

Public Class frmDeleteUser
    Dim mycnt As MySqlConnection
    Dim mysql As MySqlCommand

    Private Sub frmDeleteUser_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        mycnt = New MySqlConnection
        mycnt.ConnectionString =
            "server=localhost;userid=root;database=library;Convert Zero Datetime=True"
        Try
            mycnt.Open()
        Catch ex As Exception
            MessageBox.Show("Cannot Connect" + ex.Message)
        Finally
            mycnt.Dispose()
        End Try
    End Sub

    Private Sub BtnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnDelete.Click

        mycnt = New MySqlConnection
        mycnt.ConnectionString = "server=localhost;userid=root;database=library;Convert Zero Datetime=True"
        Dim dr As MySqlDataReader

        Try
            mycnt.Open()
            Dim Query As String
            Query = "Delete from userinfo where id='" & TxtID.Text & "'"
            mysql = New MySqlCommand(Query, mycnt)
            dr = mysql.ExecuteReader


            MessageBox.Show("Successfully Deleted")
            frmAddStudent.student()
            TxtID.Text = ""
            TxtLname.Text = ""
            TxtFname.Text = ""
            TxtMname.Text = ""
            TxtStuden.Text = ""
            Txtpass.Text = ""
            cmbyr.Text = ""
            TxtSection.Text = ""
            Me.Hide()
            mycnt.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            mycnt.Dispose()
        End Try
    End Sub

    Private Sub BtnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnCancel.Click
        frmAddStudent.Show()
        Me.Hide()
    End Sub
End Class