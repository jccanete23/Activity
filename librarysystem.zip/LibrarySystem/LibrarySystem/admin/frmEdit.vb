﻿Imports MySql.Data.MySqlClient
Public Class frmEdit
    Dim mycnt As MySqlConnection
    Dim mysql As MySqlCommand

    Private Sub frmEdit_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        mycnt = New MySqlConnection
        mycnt.ConnectionString = "server=localhost;userid=root;database=library;Convert Zero Datetime=True"
        Dim dr As MySqlDataReader

        Try
            mycnt.Open()
            Dim Query As String
            Query = "select * from category"
            mysql = New MySqlCommand(Query, mycnt)
            dr = mysql.ExecuteReader
            While dr.Read
                Dim sCategory = dr.GetString("category")
                cmbCategory.Items.Add(sCategory)
            End While

            mycnt.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            mycnt.Dispose()
        End Try
    End Sub

    Private Sub BtnEdit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnEdit.Click

        mycnt = New MySqlConnection
        mycnt.ConnectionString = "server=localhost;userid=root;database=library;Convert Zero Datetime=True"
        Dim dr As MySqlDataReader

        Try
            mycnt.Open()
            Dim Query As String
            Query = "update tblbooks set book_id='" & TxtBookid.Text & "',bk_name='" & TxtBookname.Text & "',author_name='" & TxtAuthor.Text & "',bk_ctry='" & cmbCategory.Text & "',bk_qty='" & TxtQuantity.Text & "' where book_id='" & TxtBookid.Text & "'"
            mysql = New MySqlCommand(Query, mycnt)
            dr = mysql.ExecuteReader

            MessageBox.Show("Successful Update Books")
            frmAddBooks.listbook1()
            TxtBookid.Text = ""
            TxtBookname.Text = ""
            TxtAuthor.Text = ""
            cmbCategory.Text = ""
            TxtQuantity.Text = ""
            Me.Hide()
            mycnt.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            mycnt.Dispose()
        End Try
    End Sub

    Private Sub TxtBookid_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TxtBookid.KeyDown
        If e.KeyCode.Equals(Keys.Back) Then
            TxtBookid.Clear()
        End If
    End Sub

    Private Sub TxtBookid_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TxtBookid.KeyPress
        Dim AllowedChars As String = "1234567890"
        If AllowedChars.IndexOf(e.KeyChar) = -1 Then
            e.Handled = True
        End If
    End Sub

    Private Sub TxtBookname_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TxtBookname.KeyDown
        If e.KeyCode.Equals(Keys.Back) Then
            TxtBookname.Clear()
        End If
    End Sub

    Private Sub TxtBookname_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TxtBookname.KeyPress
        Dim AllowedChars As String = "abcdefghijklnmopqrstuvwxyz"
        If AllowedChars.IndexOf(e.KeyChar) = -1 Then
            e.Handled = True
        End If
    End Sub

    Private Sub TxtAuthor_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TxtAuthor.KeyDown
        If e.KeyCode.Equals(Keys.Back) Then
            TxtAuthor.Clear()
        End If
    End Sub

    Private Sub TxtAuthor_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TxtAuthor.KeyPress
        Dim AllowedChars As String = "abcdefghijklnmopqrstuvwxyzABCDEFGHIJKLNMOPQRSTUVWXYZ"
        If AllowedChars.IndexOf(e.KeyChar) = -1 Then
            e.Handled = True
        End If
    End Sub

    Private Sub TxtQuantity_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TxtQuantity.KeyDown
        If e.KeyCode.Equals(Keys.Back) Then
            TxtQuantity.Clear()
        End If
    End Sub

    Private Sub TxtQuantity_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TxtQuantity.KeyPress
        Dim AllowedChars As String = "1234567890"
        If AllowedChars.IndexOf(e.KeyChar) = -1 Then
            e.Handled = True
        End If
    End Sub

    Private Sub BtnBck_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnBck.Click
        frmAddBooks.Show()
        Me.Hide()
    End Sub
End Class