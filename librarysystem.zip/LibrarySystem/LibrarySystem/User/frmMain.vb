﻿Imports MySql.Data.MySqlClient

Public Class frmMain

    Private Sub BooksToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BooksToolStripMenuItem.Click
        frmListBook.Show()
    End Sub

    Private Sub LogoutToolStripMenuItem2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LogoutToolStripMenuItem2.Click
        MsgBox("Thank You Student")
        Me.Close()
        konekmo()
        Dim qry = "insert into users values('','" & frmUserLogin.user & "','" & frmUserLogin.pass & "','Logout','" & Date.Now.ToString("hh:mm:dd") & "')"
        cmd = New MySqlCommand(qry, connect)
        da = cmd.ExecuteScalar
        connect.Close()

        frmUserLogin.txtUsername.Text = ""
        frmUserLogin.txtPassword.Text = ""

    End Sub
End Class