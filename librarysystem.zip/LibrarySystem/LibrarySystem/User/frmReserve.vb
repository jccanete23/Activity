﻿Imports MySql.Data.MySqlClient
Public Class frmReserve
    Dim mycnt As MySqlConnection
    Dim mysql As MySqlCommand

    Private Sub frmReserve_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        mycnt = New MySqlConnection
        mycnt.ConnectionString =
            "server=localhost;userid=root;database=library;Convert Zero Datetime=True"
        Try
            mycnt.Open()
        Catch ex As Exception
            MessageBox.Show("Cannot Connect" + ex.Message)
        Finally
            mycnt.Dispose()
        End Try
        asd()
        namoo()
    End Sub

    Dim Query As String
    Dim Reader As MySqlDataReader

    Public Sub Squery()
        Dim Query As String
        mycnt = New MySqlConnection
        mycnt.ConnectionString =
            "server=localhost;userid=root;database=library;Convert Zero Datetime=True"
        Try
            mycnt.Open()
        Catch ex As Exception
            MessageBox.Show("Cannot Connect" + ex.Message)
        Finally
            mycnt.Dispose()
        End Try

        Query = "select bk_qty from tblbooks"
    End Sub

    Private Sub BtnReserve_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnReserve.Click
        mycnt = New MySqlConnection
        mycnt.ConnectionString = "server=localhost;userid=root;database=library;Convert Zero Datetime=True"
        Dim dr As MySqlDataReader

        Try
            konekmo()
            Dim qry = "update tblbooks set bk_qty=bk_qty-" & TxtNumberCopies.Text & " where book_id='" & TxtBookid.Text & "'"
            cmd = New MySqlCommand(qry, connect)
            da = cmd.ExecuteScalar
            connect.Close()

            mycnt.Open()
            Dim Query As String
            Query = "insert into reserve(reserve_id,contact_no,reserve_name,bookid,booktle,author_name,pickup,no_copies)value ('" & TxtReserveId.Text & "','" & TxtContact.Text & "','" & TxtReserveName.Text & "','" & TxtBookid.Text & "','" & TxtBookname.Text & "','" & TxtAuthor.Text & "','" & DateTimePicker_pickup.Text & "','" & TxtNumberCopies.Text & "')"
            mysql = New MySqlCommand(Query, mycnt)
            dr = mysql.ExecuteReader

            MessageBox.Show("Successful Reserve Information")
            frmListBook.listbook()
            Me.Hide()
            mycnt.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            mycnt.Dispose()
        End Try
    End Sub

    Private Sub TxtNumberCopies_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtNumberCopies.TextChanged
        If Val(TxtNumberCopies.Text) > Val(lblQty.Text) Then
            MsgBox("Number of copies is too much", MsgBoxStyle.Exclamation, "Number of Copies")
            TxtNumberCopies.Clear()
        End If
    End Sub

    Private Sub TxtContact_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles TxtContact.Click
        TxtContact.Text = "+63"
        TxtContact.Select(4, 0)
    End Sub
    Sub asd()
        TxtReserveName.Text = frmUserLogin.firstname
    End Sub
    Sub namoo()
        TxtReserveId.Text = frmUserLogin.user
    End Sub
End Class