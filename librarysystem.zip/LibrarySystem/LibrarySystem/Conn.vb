﻿Imports MySql.Data.MySqlClient
Module Conn
    Public cmd As New MySqlCommand
    Public connect As New MySqlConnection
    Public dr As MySqlDataReader
    Public da As New MySqlDataAdapter
    Public Dataset As New DataSet
    Public conn As String = "server=localhost;user id=root;password=;database=library"

    Public Sub konekmo()
        Dim strConn As String

        strConn = "Server =localhost; userid = root; password =;"
        strConn &= "Database = library; pooling=false;"

        connect = New MySqlConnection(strConn)

        connect.Open()
    End Sub
End Module
